import 'package:flutter/material.dart';

class PopularBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: Center(
            child: Text(
              "Popular Posts",
            )
        )
    );
  }
}
