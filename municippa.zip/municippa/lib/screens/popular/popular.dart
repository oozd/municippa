import 'package:flutter/material.dart';
import 'package:municippa/screens/popular/popularBody.dart';

class Popular extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return PopularBody();
  }
}
