import 'package:flutter/material.dart';
import 'package:municippa/screens/recent/recentBody.dart';

class Recent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RecentBody();
  }
}
