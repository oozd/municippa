import 'package:flutter/material.dart';
import 'package:municippa/screens/nearMe/nearMeBody.dart';

class NearMe extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return NearMeBody();
  }
}
