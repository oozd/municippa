import 'package:flutter/material.dart';

class NearMeBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: Center(
            child: Text(
              "Near Me Posts",
            )
        )
    );
  }
}